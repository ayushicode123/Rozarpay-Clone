# RAZORPAY-CLONE
 Razorpay clone built using HTML and Tailwind CSS
 # Website Live Link:
 https://razorpayclonebyashu.netlify.app/
